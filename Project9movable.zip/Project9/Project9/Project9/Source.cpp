/*
Programmer:			William J. Heine
Program:			Assignment 9
Program .cpp:		Source.cpp
Class:				IS 275 Advanced C++ Programming
Instructor:			David Doering
Start Date:			3/27/18
Due Date:			3/27/18
*/

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

// preprocessor directive
#include <iostream>
#include <iomanip>
#include <algorithm>
#include "QuickSort.h"
#include "AreaCalc.h"
#include "Password.h"
#include "Points.h"
#include "Matrix.h"

// using the standard library
using namespace std;

//prototypes
void displayHeader();
void displayMainMenu();
void getMenuInput(int &MenuChoice);
void callSwitch1(int);

//main function directive
int main()
{
	int MenuChoice = 0;
	char Cont;

	do
	{
		//program running
		//++++++++++++++++
		system("CLS");
		displayHeader();
		displayMainMenu();
		getMenuInput(MenuChoice);
		callSwitch1(MenuChoice);
		//++++++++++++++++

		cout << setw(5) << " " << "would you like to continue (Y/N) ";
		cin >> Cont;
		Cont = toupper(Cont);

	} while (Cont != 'N');

	system("pause");
	return 0;
}


//Display header function
void displayHeader()
{
	cout << "\n";
	cout << setw(27) << " " << "Trash OS\n";
	cout << setw(22) << " " << "by William J. Heine\n";
	cout << setw(24) << " " << "March 26, 2018\n\n";
}

//Display menu function
void displayMainMenu()
{
	cout << setw(25) << " " << "Operations\n\n\n\n";
	cout << setw(5) << " " << "1. Quicksort\n";
	cout << setw(5) << " " << "2. Password\n";
	cout << setw(5) << " " << "3. Area Calculator\n";
	cout << setw(5) << " " << "4. Enter Grades\n";
	cout << setw(5) << " " << "5. Grab the last few points\n";
}

//Get menu input function
void getMenuInput(int &menuchoice)
{
	cout << "\n";
	cout << setw(5) << " " << "Enter a menu choice: ";
	cin >> menuchoice;
}

//The switch
void callSwitch1(int menuchoice)
{
	QuickSort taco;
	AreaCalc burrito;
	Password tamale;
	Points churro;
	Matrix quesadilla;

	switch (menuchoice)
	{
	case 1: system("CLS");
			displayHeader();
			taco.runSort();
		break;

	case 2: system("CLS");
			displayHeader();
			tamale.runPassword();
		break;

	case 3: system("CLS");
			displayHeader();
			burrito.runCalc();
		break;

	case 4: system("CLS");
			displayHeader();
			quesadilla.runMatrix();
		break;

	case 5: system("CLS");
		displayHeader();
		churro.runPoints();
		break;

	default: cout << setw(5) << " " << "You have not entered a menu choice.\n";
	}
}
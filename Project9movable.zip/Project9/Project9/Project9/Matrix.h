#pragma once
#ifndef Matrix_H
#define Matrix_H

// preprocessor directive
#include <iostream>
#include <iomanip>

// using the standard library
using namespace std;

class Matrix
{
private:
	const static int s = 3;
	const static int t = 4;
public:
	double Scores[s][t];

	void runMatrix();
	void inputTestScores();
	void displayScores();

};

//runs the stuff
void Matrix::runMatrix()
{
	inputTestScores();
	displayScores();
}

//input area
void Matrix::inputTestScores()
{
	cout << setw(10) << " " << "Enter the four Test Scores for each student";

	for (int stu = 0; stu < s; stu++)
	{
		cout << "\n\n";
		cout << setw(10) << " " << "Enter scores for Student " << (stu + 1);
		cout << "\n\n";

		for (int tes = 0; tes < t; tes++)
		{
			cout << setw(20) << " " << "Test Score" << (tes + 1) << ": ";
			cin >> Scores[stu][tes];
		}

	}
}

//output area
void Matrix::displayScores()
{
	system("CLS");

	double Holder = 0.0;

	char Grade = ' ';

	cout << setw(30) << " " << "Score 1" << setw(15) << "Score 2" << setw(15) << "Score 3" << setw(15) << "Score 4" << setw(20) << "Letter Grade\n\n";

	for (int stu = 0; stu < s; stu++)
	{
		cout << "Student " << (stu + 1) << setw(11) << "==> ";

		Holder = 0.0;

		for (int tes = 0; tes < t; tes++)
		{
			cout << setw(15) << Scores[stu][tes];
			Holder += Scores[stu][tes];
		}

		Holder = (Holder / 4);

		if (Holder > 90)
		{
			Grade = 'A';
		}
		else if (Holder > 80)
		{
			Grade = 'B';
		}
		else if (Holder > 70)
		{
			Grade = 'C';
		}
		else if (Holder > 60)
		{
			Grade = 'D';
		}
		else
		{
			Grade = 'F';
		}

		cout << setw(15) << Grade;
		cout << "\n\n";
	}
}

#endif Matrix_H
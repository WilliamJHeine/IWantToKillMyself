#pragma once
#ifndef Points_H
#define Points_H

// preprocessor directive
#include <iostream>
#include <iomanip>

// using the standard library
using namespace std;

//have some class
class Points
{
private:

public:

	void runPoints();
	void enumThing();
	void sentinelThing();

};

//I just want the points
void Points::runPoints()
{
	bool check;

	cout << setw(5) << " " << "Are you sure you want to see this part of the program? (1 for yes, 0 for no) ";
	cin >> check;

	if (check == true)
	{
		cout << setw(5) << " " << "okay, go ahead and look at this enumerated data thing.\n";
		enumThing();

		cout << setw(5) << " " << "Are you sure you want to keep going? (1 for yes, 0 for no) ";
		cin >> check;
		cout << endl;

		if (check == true)
		{
			cout << setw(5) << " " << "okay, go ahead and enter some data you want to add.\n";
			sentinelThing();
		}
	}
	cout << setw(5) << " " << "that was a shame wasn't it.\n\n";
}

//I really need the points
void Points::enumThing()
{
	enum things { Tom = 1, Sharon, Bill, Teresa, John };

	int who;

	cout << setw(5) << " " << "This bit will give you a random name's birthday\n";
	cout << setw(5) << " " << "Select a name\n";
	cout << setw(5) << " " << "1 = Tom\n";
	cout << setw(5) << " " << "2 = Sharon\n";
	cout << setw(5) << " " << "3 = Bill\n";
	cout << setw(5) << " " << "4 = Teresa\n";
	cout << setw(5) << " " << "5 = John\n";
	cout << setw(5) << " " << "Enter 1-5 for your choice: ";

	cin >> who;

	cout << endl;

	switch (who)
	{
	case Tom:	cout << setw(5) << " " << "Tom's birthday is Jan. 3rd\n";
				break;
	case Sharon:	cout << setw(5) << " " << "Sharon's birthday is Apr. 22nd\n";
		break;
	case Bill:	cout << setw(5) << " " << "Bill's birthday is Dec. 19th\n";
		break;
	case Teresa:	cout << setw(5) << " " << "Teresa's birthday is Feb. 2nd\n";
		break;
	case John:	cout << setw(5) << " " << "John's birthday is Jun. 17th\n";
		break;
	}
	cout << endl;
}

//hook a brother up
void Points::sentinelThing()
{
	int points = 0,
		total = 0;

	while (points != -1)
	{
		total += points;
		cout << setw(5) << " " << "Enter in another value or -1 to finish: ";
		cin >> points;
	}

	cout << setw(5) << " " << "Here is the total: " << total << "\n\n";
}

#endif Points_H
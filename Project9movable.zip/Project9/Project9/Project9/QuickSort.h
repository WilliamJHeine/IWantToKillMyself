#pragma once
#ifndef QuickSort_H
#define QuickSort_H

#include <iostream>
#include <algorithm>
using namespace std;

class QuickSort
{
private:
	const static int SIZE = 10;
public:
	int array[SIZE] = { 17,53,9,230,1,82,64,26,5 };

	QuickSort::QuickSort()
	{

	}

	void runSort();
	void getNumbers();
	void quickSort(int[], int, int);
	int partition(int[], int, int);

	QuickSort::~QuickSort()
	{

	}
};

// runs the class
void QuickSort::runSort()
{
	getNumbers();

	cout << setw(5) << " " << "Your input\n";
	//echo the array to be sorted
	for (int k = 0; k < SIZE; k++)
	{
		cout << setw(5) << " " << array[k] << " ";
	}
	cout << endl;

	cout << setw(5) << " " << "Your sorted output\n";
	// sort the array using quicksort
	quickSort(array, 0, SIZE - 1);

	//print the sorted array
	for (int k = 0; k < SIZE; k++)
	{
		cout << setw(5) << " " << array[k] << " ";
	}
	cout << "\n\n";
}

//user input
void QuickSort::getNumbers()
{
	for (int k = 0; k < SIZE; k++)
	{
		cout << setw(5) << " " << "Enter a number for slot  " << (k+1) << " :";
		cin >> array[k];
	}
	cout << endl;
}

//the quicksort using recursion
void QuickSort::quickSort(int arr[], int start, int end)
{
	if (start < end)
	{
		//partition the array and get a pivot point
		int p = partition(arr, start, end);

		//sort the portion before the pivot point
		quickSort(arr, start, p - 1);

		//sort the portion after the pivot point
		quickSort(arr, p + 1, end);
	}
}

//the partition section
int QuickSort::partition(int arr[], int start, int end)
{
	int pivotValue = arr[start];
	int pivotPosition = start;

	for (int pos = start + 1; pos <= end; pos++)
	{
		if (arr[pos] < pivotValue)
		{
			swap(arr[pivotPosition + 1], arr[pos]);
			swap(arr[pivotPosition], arr[pivotPosition + 1]);
			pivotPosition++;
		}
	}
	return pivotPosition;
}

#endif QuickSort_H
#pragma once
#ifndef AreaCalc_H
#define AreaCalc_H
#define _USE_MATH_DEFINES

#include <iostream>
#include <iomanip>
#include <cmath>
#include <math.h>

// using the standard library
using namespace std;

// A simple Shape interface which provides a method to get the Shape's area
class Shape {
public:
	virtual float getArea() const = 0;
};


// A Rectangle is a Shape with a specific width and height
class Rectangle : public Shape {
private:
	float width;
	float height;

public:
	Rectangle(float width, float height) : width(width), height(height) { }
	virtual float getArea() const { return width * height; }
};

// A Circle is a Shape with a specific radius
class Circle : public Shape {
private:
	float radius;

public:
	Circle(float radius) : radius(radius) { }
	virtual float getArea() const { return 3.14159 * radius * radius; }
};

// A Right Polygon is a shape with a specific sidelength
class Polygon : public Shape {
private:
	float sideLength;
	float sides;

public:
	Polygon(float sideLength, float sides) : sideLength(sideLength), sides(sides) { }
	virtual float getArea() const { return (0.5 * (sides * sideLength) * (sideLength/(2*tan(M_PI/sides)))); }
};

class AreaCalc
{
public:
	void printArea(const Shape& shape);
	void runCalc();
};

void AreaCalc::printArea(const Shape& shape) {
	std::cout << setw(5) << " " << "Area: " << shape.getArea() << std::endl;
}

// runs the class
void AreaCalc::runCalc()
{
	int taco = 0,
		num1 = 0,
		num2 = 0;

	Shape* shape;

	//<><><><><><><><><><><><><><><><><><><><><>

		if (taco < 1 || taco > 3)
		{
			cout << setw(5) << " " << "1)   determine the area of a rectangle\n";
			cout << setw(5) << " " << "2)   determine the area of a circle\n";
			cout << setw(5) << " " << "3)   determine the area of a polygon\n";
			cout << endl;
			cout << setw(5) << " " << "please enter a choice: ";
			cin >> taco;
		}

		switch (taco)
		{
		case 1:		cout << endl;
			cout << setw(5) << " " << "Enter a length: ";
			cin >> num1;
			cout << endl;
			cout << setw(5) << " " << "Enter a width: ";
			cin >> num2;

			shape = &Rectangle(num1, num2);

			printArea(*shape);
			break;

		case 2:		cout << endl;
			cout << setw(5) << " " << "Enter a radius: ";
			cin >> num1;

			shape = &Circle(num1);

			printArea(*shape);
			break;

		case 3:		cout << endl;
			cout << setw(5) << " " << "Enter a side length: ";
			cin >> num1;
			cout << endl;
			cout << setw(5) << " " << "Enter a number of sides: ";
			cin >> num2;

			shape = &Polygon(num1, num2);

			printArea(*shape);
			break;

		default:
			break;
		}
	//<><><><><><><><><><><><><><><><><><><><><>
	cout << endl;
}

#endif AreaCalc_H
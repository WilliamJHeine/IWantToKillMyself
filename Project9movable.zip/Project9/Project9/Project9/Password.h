#pragma once
#ifndef Password_H
#define Password_H

// preprocessor directive
#include <iostream>
#include <iomanip>
#include <string>

// using the standard library
using namespace std;

class Password
{
public:
	void runPassword();
	void displayProgramDescription();
	void capitalize(char *holder);
	void substitution(char *holder);
	void removeVowelsAndSpaces(char *holder);
	bool isVowel(char);
	void errorChecking(char *holder);
};

//runs the class
void Password::runPassword()
{
	displayProgramDescription();

	string holder;

	const int working_number = 81;
	char *working = nullptr;
	working = new char[working_number];
	char phrase[working_number];

	cout << endl;

	cout << setw(5) << " " << "Enter a 2 to 4 word phrase (with letters 'd' and 'n'):\n";
	cout << setw(5) << " " << ">> ";
	cin.ignore();
	cin.getline(working, working_number);

	strcpy_s(phrase, working);//copy

	capitalize(working);//capitalize 4th letter in each word
	substitution(working);//replace one character with another
	removeVowelsAndSpaces(working);//remove vowels and spaces
	errorChecking(working);//enter the suggested output

	cout << setw(5) << " " << "Thank you for playing\n";
	cout << setw(5) << " " << "Based on the phrase: " << phrase << "\n";
	cout << setw(5) << " " << "We recommend you use the password: " << working << "\n";

	cout << endl;

	//delete dynamic array memory
	delete[] working;
	working = nullptr;
}

//display program discription
void Password::displayProgramDescription()
{
	cout << setw(5) << " " << "Have you ever had trouble creating a secure password?\n";
	cout << setw(5) << " " << "This program requests a phrase from the user.\n";
	cout << setw(5) << " " << "The program then manipulates the origional phrase.\n";
	cout << setw(5) << " " << "The resulting output is a suggested password.\n";
}

//capitalize function
void Password::capitalize(char *holder)
{
	for (int i = 4; i <= 81; i += 4)
	{
		*(holder + i) = toupper(*(holder + i));
	}
}

//substitution function
void Password::substitution(char *holder)
{
	string jericho = holder;

	for (int i = 0; *(holder + i) != '\0'; i++)
	{
		if ('d' == (*(holder + i)))
		{
			//(*(holder + i)) = '$';
			jericho.replace(i, 1, "$");
		}
		else if ('n' == (*(holder + i)))
		{
			//(*(holder + i)) = '9';
			jericho.replace(i, 1, "9");
		}
	}

	strcpy(holder, jericho.c_str());
}

//selective delete function
void Password::removeVowelsAndSpaces(char *holder)
{
	for (int i = 0; *(holder + i) != '\0'; i++)
	{
		if (isVowel(*(holder + i)))
		{
			for (int c = i; *(holder + c) != '\0'; c++)
				*(holder + c) = *(holder + (c + 1));

			i--;
		}
	}
}

//vowel marking function
bool Password::isVowel(char ch)
{
	ch = toupper(ch);
	return (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == ' ');
}

//input test function
void Password::errorChecking(char *holder)
{
	char test[81];

	cout << endl;
	cout << setw(5) << " " << "Your suggested password is: " << holder << "\n";
	cout << setw(5) << " " << "Practice using your 'new' password.\n";
	cout << setw(5) << " " << "Enter the password: ";
	cin.getline(test, 81);

	cout << endl;

	if (!strcmp(holder, test))
	{
		cout << setw(5) << " " << "Concratulations, you have entered the correct password!\n\n";
	}
	else
	{
		cout << setw(5) << " " << "The string you entered does NOT match\n";
		cout << setw(5) << " " << "the sample password!\n\n";
	}
}

#endif Password_H